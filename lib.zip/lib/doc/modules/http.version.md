## http.version

### `name` <!-- --> {#http.version.name}

`"lua-http"`


### `version` <!-- --> {#http.version.version}

Current version of lua-http as a string.
